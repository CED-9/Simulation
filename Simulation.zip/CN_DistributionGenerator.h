#ifndef CN_Distribution
#define CN_Distribution
#include <iostream>
#include <vector>

class DisGenerator{
public:
    void normalPartition(double total, int cnt, std::vector<double> & result);
};

#endif