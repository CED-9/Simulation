# Simulation
Credit Network Simulation

make compile
./test $a $b
a: mechanism mode
-- 1: all nodes FF
-- 2: all nodes LP_SOURCE
-- 3: all nodes LP_OVERALL
-- 4: all nodes random
b: number of total interest rates

# Network info
200 Financial nodes
Erdos Renyi Graph
two edges between two nodes (one credit, one debt)
when unique IR, same settings with liquidity paper
